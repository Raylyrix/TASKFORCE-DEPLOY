// src/auth-callback/index.ts
var urlParams = new URLSearchParams(window.location.search);
var code = urlParams.get("code");
var state = urlParams.get("state");
var error = urlParams.get("error");
var loadingEl = document.getElementById("loading");
var errorEl = document.getElementById("error");
var successEl = document.getElementById("success");
var errorMessageEl = document.getElementById("error-message");
if (error) {
  if (loadingEl) loadingEl.style.display = "none";
  if (errorEl) errorEl.style.display = "block";
  if (errorMessageEl) {
    errorMessageEl.textContent = `Authentication failed: ${decodeURIComponent(error)}`;
  }
  try {
    chrome.runtime.sendMessage(
      chrome.runtime.id,
      {
        type: "AUTH_CALLBACK_ERROR",
        error: decodeURIComponent(error)
      },
      () => {
        setTimeout(() => {
          window.close();
        }, 3e3);
      }
    );
  } catch (e) {
    console.error("Failed to send error to extension:", e);
  }
} else if (code && state) {
  try {
    chrome.runtime.sendMessage(
      chrome.runtime.id,
      {
        type: "AUTH_CALLBACK",
        code,
        state
      },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error("Error sending message:", chrome.runtime.lastError);
          if (loadingEl) loadingEl.style.display = "none";
          if (errorEl) errorEl.style.display = "block";
          if (errorMessageEl) {
            errorMessageEl.textContent = "Failed to communicate with extension. Please try again.";
          }
          return;
        }
        if (response?.error) {
          if (loadingEl) loadingEl.style.display = "none";
          if (errorEl) errorEl.style.display = "block";
          if (errorMessageEl) {
            errorMessageEl.textContent = response.error;
          }
        } else {
          if (loadingEl) loadingEl.style.display = "none";
          if (successEl) successEl.style.display = "block";
          setTimeout(() => {
            window.close();
          }, 2e3);
        }
      }
    );
  } catch (e) {
    console.error("Failed to send message to extension:", e);
    if (loadingEl) loadingEl.style.display = "none";
    if (errorEl) errorEl.style.display = "block";
    if (errorMessageEl) {
      errorMessageEl.textContent = "Failed to communicate with extension. Please try again.";
    }
  }
} else {
  if (loadingEl) loadingEl.style.display = "none";
  if (errorEl) errorEl.style.display = "block";
  if (errorMessageEl) {
    errorMessageEl.textContent = "Missing authentication parameters. Please try again.";
  }
}
//# sourceMappingURL=auth-callback.js.map