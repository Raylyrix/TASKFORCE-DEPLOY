// src/shared/storage.ts
var getArea = (area) => area === "local" ? chrome.storage.local : chrome.storage.sync;
var wrapGet = async (area, key) => new Promise((resolve, reject) => {
  try {
    if (typeof chrome === "undefined" || typeof chrome.runtime === "undefined" || chrome.runtime.id === void 0) {
      reject(new Error("Extension context invalidated"));
      return;
    }
  } catch {
    reject(new Error("Extension context invalidated"));
    return;
  }
  getArea(area).get([key], (result) => {
    if (chrome.runtime.lastError) {
      const error = chrome.runtime.lastError;
      if (error.message?.includes("Extension context invalidated") || error.message?.includes("message port closed")) {
        reject(new Error("Extension context invalidated"));
      } else {
        reject(error);
      }
      return;
    }
    resolve(result[key]);
  });
});
var wrapSet = async (area, key, value) => new Promise((resolve, reject) => {
  try {
    if (typeof chrome === "undefined" || typeof chrome.runtime === "undefined" || chrome.runtime.id === void 0) {
      reject(new Error("Extension context invalidated"));
      return;
    }
  } catch {
    reject(new Error("Extension context invalidated"));
    return;
  }
  getArea(area).set({ [key]: value }, () => {
    if (chrome.runtime.lastError) {
      const error = chrome.runtime.lastError;
      if (error.message?.includes("Extension context invalidated") || error.message?.includes("message port closed")) {
        reject(new Error("Extension context invalidated"));
      } else {
        reject(error);
      }
      return;
    }
    resolve();
  });
});
var storage = {
  async getLocal(key) {
    return wrapGet("local", key);
  },
  async setLocal(key, value) {
    return wrapSet("local", key, value);
  },
  async getSync(key) {
    return wrapGet("sync", key);
  },
  async setSync(key, value) {
    return wrapSet("sync", key, value);
  }
};

// src/shared/auth.ts
var AUTH_KEY = "authState";
var isExtensionContextValid = () => {
  try {
    return typeof chrome !== "undefined" && typeof chrome.runtime !== "undefined" && chrome.runtime.id !== void 0;
  } catch {
    return false;
  }
};
var getAuthState = async () => {
  if (!isExtensionContextValid()) {
    console.warn("[TaskForce] Extension context invalidated, cannot get auth state");
    return void 0;
  }
  try {
    return await storage.getLocal(AUTH_KEY);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes("Extension context invalidated") || errorMessage.includes("message port closed")) {
      console.warn("[TaskForce] Extension context invalidated, cannot get auth state");
      return void 0;
    }
    throw error;
  }
};
var setAuthState = async (state) => {
  if (!isExtensionContextValid()) {
    console.warn("[TaskForce] Extension context invalidated, cannot set auth state");
    return;
  }
  try {
    await storage.setLocal(AUTH_KEY, state);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes("Extension context invalidated") || errorMessage.includes("message port closed")) {
      console.warn("[TaskForce] Extension context invalidated, cannot set auth state");
      return;
    }
    throw error;
  }
};
var clearAuthState = async () => {
  if (!isExtensionContextValid()) {
    console.warn("[TaskForce] Extension context invalidated, cannot clear auth state");
    return;
  }
  try {
    await storage.setLocal(AUTH_KEY, null);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes("Extension context invalidated") || errorMessage.includes("message port closed")) {
      console.warn("[TaskForce] Extension context invalidated, cannot clear auth state");
      return;
    }
    throw error;
  }
};

// src/shared/config.ts
var BACKEND_URL_KEY = "backendUrl";
var DEFAULT_BACKEND_URL = "https://taskforce-backend-production.up.railway.app";
var isExtensionContextValid2 = () => {
  try {
    return typeof chrome !== "undefined" && typeof chrome.runtime !== "undefined" && chrome.runtime.id !== void 0;
  } catch {
    return false;
  }
};
var getBackendUrl = async () => {
  if (!isExtensionContextValid2()) {
    console.warn("[TaskForce] Extension context invalidated, using default backend URL");
    return DEFAULT_BACKEND_URL;
  }
  try {
    const stored = await storage.getSync(BACKEND_URL_KEY);
    return stored ?? DEFAULT_BACKEND_URL;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes("Extension context invalidated") || errorMessage.includes("message port closed") || !isExtensionContextValid2()) {
      console.warn("[TaskForce] Extension context invalidated, using default backend URL");
      return DEFAULT_BACKEND_URL;
    }
    console.warn("[TaskForce] Failed to get backend URL from storage, using default:", error);
    return DEFAULT_BACKEND_URL;
  }
};
var setBackendUrl = async (backendUrl) => {
  if (!isExtensionContextValid2()) {
    console.warn("[TaskForce] Extension context invalidated, cannot set backend URL");
    return;
  }
  try {
    await storage.setSync(BACKEND_URL_KEY, backendUrl);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes("Extension context invalidated") || errorMessage.includes("message port closed")) {
      console.warn("[TaskForce] Extension context invalidated, cannot set backend URL");
      return;
    }
    throw error;
  }
};

// src/background/index.ts
var ensureBackendConfigured = async () => {
  const backendUrl = await getBackendUrl();
  if (!backendUrl) {
    await setBackendUrl(DEFAULT_BACKEND_URL);
  }
};
chrome.runtime.onInstalled.addListener(() => {
  void ensureBackendConfigured();
});
var pendingAuthState = null;
var isProcessingCallback = false;
var handleAuthStart = async (payload) => {
  const backendUrl = await getBackendUrl();
  const redirectUri = `${backendUrl}/api/auth/google/callback`;
  const extensionId = crypto.randomUUID();
  const startResponse = await fetch(`${backendUrl}/api/auth/google/start`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Request-Source": "extension"
      // Explicitly mark as extension request
    },
    body: JSON.stringify({ redirectUri, extensionId })
    // Send extensionId - foolproof identifier
  });
  if (!startResponse.ok) {
    throw new Error(`Failed to initialize OAuth: ${await startResponse.text()}`);
  }
  const { url, state } = await startResponse.json();
  const authPromise = new Promise((resolve, reject) => {
    pendingAuthState = { state, resolve, reject };
    setTimeout(() => {
      if (pendingAuthState?.state === state) {
        pendingAuthState = null;
        reject(new Error("Authentication timeout"));
      }
    }, 5 * 60 * 1e3);
  });
  chrome.tabs.create(
    {
      url,
      active: true
    },
    (tab) => {
      if (chrome.runtime.lastError || !tab || !tab.id) {
        if (pendingAuthState?.state === state) {
          pendingAuthState.reject(new Error("Failed to open authentication tab"));
          pendingAuthState = null;
        }
        return;
      }
      const tabId = tab.id;
      let tabListener = null;
      let timeoutId = null;
      tabListener = (updatedTabId, changeInfo, updatedTab) => {
        if (updatedTabId !== tabId) return;
        if (changeInfo.status !== "complete" || !updatedTab.url) return;
        const tabUrl = updatedTab.url;
        if (tabUrl.includes("/api/auth/google/callback") || tabUrl.includes("/auth/callback")) {
          try {
            const url2 = new URL(tabUrl);
            const callbackCode = url2.searchParams.get("code");
            const callbackState = url2.searchParams.get("state");
            const error = url2.searchParams.get("error");
            if (tabListener) {
              chrome.tabs.onUpdated.removeListener(tabListener);
              tabListener = null;
            }
            if (timeoutId) {
              clearTimeout(timeoutId);
              timeoutId = null;
            }
            if (error) {
              if (pendingAuthState?.state === state) {
                pendingAuthState.reject(new Error(decodeURIComponent(error)));
                pendingAuthState = null;
              }
              chrome.tabs.remove(tabId).catch(() => {
              });
              return;
            }
            if (callbackCode && callbackState && callbackState === state && !isProcessingCallback) {
              setTimeout(() => {
                if (!isProcessingCallback && pendingAuthState?.state === state) {
                  chrome.tabs.remove(tabId).catch(() => {
                  });
                  handleAuthCallback(callbackCode, callbackState).catch((err) => {
                    if (pendingAuthState?.state === state) {
                      pendingAuthState.reject(err);
                      pendingAuthState = null;
                      isProcessingCallback = false;
                    }
                  });
                } else if (isProcessingCallback) {
                  chrome.tabs.remove(tabId).catch(() => {
                  });
                }
              }, 500);
            } else if (isProcessingCallback) {
              chrome.tabs.remove(tabId).catch(() => {
              });
            }
          } catch (err) {
            console.error("Error processing auth callback:", err);
            if (pendingAuthState?.state === state) {
              pendingAuthState.reject(new Error("Failed to process authentication callback"));
              pendingAuthState = null;
            }
            if (tabListener) {
              chrome.tabs.onUpdated.removeListener(tabListener);
              tabListener = null;
            }
            if (timeoutId) {
              clearTimeout(timeoutId);
              timeoutId = null;
            }
          }
        }
      };
      chrome.tabs.onUpdated.addListener(tabListener);
      timeoutId = setTimeout(() => {
        if (tabListener) {
          chrome.tabs.onUpdated.removeListener(tabListener);
          tabListener = null;
        }
        if (pendingAuthState?.state === state) {
          pendingAuthState.reject(new Error("Authentication timeout"));
          pendingAuthState = null;
        }
        chrome.tabs.get(tabId, (tab2) => {
          if (tab2) {
            chrome.tabs.remove(tabId).catch(() => {
            });
          }
        });
      }, 5 * 60 * 1e3);
    }
  );
  return authPromise;
};
var handleAuthCallback = async (code, state) => {
  if (isProcessingCallback) {
    console.log("Callback already being processed, ignoring duplicate");
    return;
  }
  if (!pendingAuthState || pendingAuthState.state !== state) {
    throw new Error("Invalid or expired OAuth state");
  }
  isProcessingCallback = true;
  const backendUrl = await getBackendUrl();
  try {
    const exchangeResponse = await fetch(`${backendUrl}/api/auth/google/exchange`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ code, state })
    });
    if (!exchangeResponse.ok) {
      const errorText = await exchangeResponse.text();
      throw new Error(`OAuth exchange failed: ${errorText}`);
    }
    const { user } = await exchangeResponse.json();
    const authState = { user };
    await setAuthState(authState);
    pendingAuthState.resolve(authState);
    pendingAuthState = null;
    isProcessingCallback = false;
    return authState;
  } catch (error) {
    pendingAuthState.reject(error);
    pendingAuthState = null;
    isProcessingCallback = false;
    throw error;
  }
};
var handleAuthStatus = async () => {
  const authState = await getAuthState();
  return authState ?? null;
};
var handleAuthSignOut = async () => {
  await clearAuthState();
};
var handleConfigSet = async (backendUrl) => {
  await setBackendUrl(backendUrl);
  return { backendUrl };
};
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    const processMessage = async () => {
      switch (message.type) {
        case "AUTH_START" /* AuthStart */:
          return handleAuthStart(message.payload);
        case "AUTH_STATUS" /* AuthStatus */:
          return handleAuthStatus();
        case "AUTH_SIGN_OUT" /* AuthSignOut */:
          return handleAuthSignOut();
        case "CONFIG_GET" /* ConfigGet */:
          return { backendUrl: await getBackendUrl() };
        case "CONFIG_SET" /* ConfigSet */:
          return handleConfigSet(message.payload.backendUrl);
        default:
          throw new Error(`Unhandled message type: ${message.type}`);
      }
    };
    processMessage().then((result) => {
      sendResponse(result);
    }).catch((error) => {
      console.error("Background message error", error);
      sendResponse({ error: error.message });
    });
    return true;
  }
);
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "AUTH_CALLBACK") {
    handleAuthCallback(message.code, message.state).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Auth callback error:", error);
      sendResponse({ error: error.message });
    });
    return true;
  } else if (message.type === "AUTH_CALLBACK_ERROR") {
    if (pendingAuthState) {
      pendingAuthState.reject(new Error(message.error || "Authentication failed"));
      pendingAuthState = null;
    }
    sendResponse({ success: true });
    return true;
  }
});
//# sourceMappingURL=index.js.map